// CADASTRO DE USUÁRIOS

// instalar pacotes para aplicação
const express = require('express');
const cors = require('cors');
// definir a porta e intanciar o express
const porta = 3009;
const app = express()
// habilitar o cors e a utilização de json nas requisiçoes
app.use(cors());
app.use(express.json());
// testar o servidor
app.listen(porta, () => console.log("Rodando na porta " + porta));
// Importar a conexão com o banco
const connection = require('./db_config');
 
// criar as rotas post para cadastrar novo usuario
app.post('/cadastro/cadastrar', (request, response) => {
    // criar um array com dados recebidos
    let params = Array(
        request.body.nome,
        request.body.email,
        request.body.senha
    );
    // criar o comando de execução no banco de dados
    let query = "INSERT INTO cadastro(nome, email, senha) VALUES(?,?,?);";
    // passar o comando e os dados para a função query
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});
 
app.get('/cadastro/listar', (request, response) => {
    const query = "SELECT * FROM cadastro";
 
    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});
 
app.put('/cadastro/editar/:id', (request, response) => {
    // Parâmetros da consulta
    let params = [
        request.body.nome,  // Nova senha
 request.params.id    // ID do usuário
    ];
    // Consulta SQL
    let query = "UPDATE cadastro SET nome = ? WHERE id_usuario = ?;";
    // Executando a consulta
    connection.query(query, params, (err, results) => {
        if (err) {
            // Caso haja erro
            return response.status(400).json({
                success: false,
                message: "Erro ao atualizar a senha",
                data: err
            });
        }
        // Caso de sucesso
        response.status(200).json({
            success: true,
            message: "Senha atualizada com sucesso",
            data: results
        });
    });
 });

 
app.delete('/cadastro/deletar/:id', (request, response) => {
    let id = request.params.id;
 
    let query = "DELETE FROM cadastro WHERE id_usuario = ?;"
 
    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});
 


// CADASTRO DE PRODUTOS

// criar as rotas post para cadastrar novo usuario
app.post('/produtos/cadastrar', (request, response) => {
    // criar um array com dados recebidos
    let params = Array(
        request.body.nome,
        request.body.descricao,
        request.body.preco,
    );
    // criar o comando de execução no banco de dados
    let query = "INSERT INTO produtos(nome, descricao, preco) VALUES(?,?,?);";
    // passar o comando e os dados para a função query
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    menssage: "sem sucesso",
                    data: err
                })
        }
    })
});
 
app.get('/produtos/listar', (request, response) => {
    const query = "SELECT * FROM produtos";
 
    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});
 
app.put('/produtos/editar/:id', (request, response) => {
    let params = Array(
        request.body.nome
    );
    let query = "UPTADE produtos SET nome = ?"
 
    connection.query(query, params, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});
 
app.delete('/produtos/deletar/:id', (request, response) => {
    let id = request.params.id;
 
    let query = "DELETE FROM produtos WHERE id = ?;"
 
    connection.query(query, [id], (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "sucesso",
                    data: results
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "sem sucesso",
                    data: err
                })
        }
    })
});
 