// faz com que os usuários cadastrados vá para o banco de dados ao clicar em "cadastrar"

async function cadastrar(event) {
    event.preventDefault();
 
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
 
    const data = {nome, email, senha };
    console.log(data)
 
    const response = await fetch('http://localhost:3009/cadastro/cadastrar', {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)
    })
 
    const results = await response.json();
 
    if (results.success) {
        console.log(results.menssage)
    } else {
        console.log(alert.menssage)
    }
}
