// Adicionar novos produtos

document.addEventListener('DOMContentLoaded', () => {
    const adicionarProdutoBtn = document.getElementById('adicionarProdutoBtn');
    const productModal = document.getElementById('product-modal');
    const productOverlay = document.getElementById('product-overlay');
    const closeProductModalBtn = document.getElementById('closeProductModalBtn');
    const addProductForm = document.getElementById('add-product-form');
    const productList = document.getElementById('product-list');

    // Abrir o modal
    const openModal = () => {
        productModal.classList.remove('hidden');
        productOverlay.classList.remove('hidden');
    };

    // Fechar o modal
    const closeModal = () => {
        productModal.classList.add('hidden');
        productOverlay.classList.add('hidden');
    };

    // Evento de clique para abrir o modal
    adicionarProdutoBtn.addEventListener('click', (e) => {
        e.preventDefault();
        openModal();
    });

    // Evento de clique para fechar o modal
    closeProductModalBtn.addEventListener('click', closeModal);
    productOverlay.addEventListener('click', closeModal);

    // Adicionar produto ao catálogo
    const addProductToCatalog = (event) => {
        event.preventDefault();

        // Captura os valores do formulário
        const productName = document.getElementById('product-name').value;
        const productDescription = document.getElementById('product-description').value;
        const productPrice = document.getElementById('product-price').value;

        // Cria um novo elemento para o produto
        const productItem = document.createElement('div');
        productItem.className = 'product-item';
        productItem.innerHTML = `
            <h3>${productName}</h3>z
            <p>${productDescription}</p>
            <span>Preço: ${productPrice}</span>
        `;

        // Adiciona o produto ao final da lista
        productList.appendChild(productItem);

        // Limpa o formulário e fecha o modal
        addProductForm.reset();
        closeModal();
    };

    // Adiciona o evento de submit ao formulário
    addProductForm.addEventListener('submit', addProductToCatalog);
});

