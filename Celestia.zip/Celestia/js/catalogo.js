// // faz com que o produto adicionado vá para o banco de dados ao clicar em "adicionar ao catálogo"

async function catalogo(event) {
    event.preventDefault();
 
    const nome = document.getElementById('product-name').value;
    const descricao = document.getElementById('product-description').value;
    const preco = document.getElementById('product-price').value;
 
    const data = {nome, descricao, preco };
    console.log(data)
 
    const response = await fetch('http://localhost:3009/produtos/cadastrar', {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)
    })
 
    const results = await response.json();
 
    if (results.success) {
        console.log(results.menssage)
    } else {
        console.log(alert.menssage)
    }
}

 