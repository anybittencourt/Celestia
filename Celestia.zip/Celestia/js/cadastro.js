// Abrir modal de cadastro de usuário

document.addEventListener('DOMContentLoaded', (event) => {
    const openModalBtn = document.getElementById('openModalBtn');
    const overlay = document.getElementById('overlay');
    const modal = document.getElementById('registration-form-container');
    const closeBtn = document.getElementById('closeBtn');

    openModalBtn.addEventListener('click', () => {
        overlay.classList.remove('hidden');
        modal.classList.remove('hidden');
    });

    overlay.addEventListener('click', () => {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
    });

    closeBtn.addEventListener('click', () => {
        overlay.classList.add('hidden');
        modal.classList.add('hidden');
    });
});

