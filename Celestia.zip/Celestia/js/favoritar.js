// Muda a cor quando clicar
document.addEventListener('DOMContentLoaded', () => {
    const favoriteButtons = document.querySelectorAll('.favorite-btn');

    favoriteButtons.forEach(button => {
        button.addEventListener('click', () => {
            button.classList.toggle('clicked');
        });
    });
});

document.addEventListener('DOMContentLoaded', (event) => {
    const favoritesIcon = document.getElementById('favoritesIcon');
    const favoritesOverlay = document.getElementById('favorites-overlay');
    const favoritesModal = document.getElementById('favorites-modal');
    const closeFavoritesBtn = document.getElementById('closeFavoritesBtn');
    const favoritesList = document.getElementById('favorites-list');
    let favoriteProducts = [];

    // Abrir modal de favoritos
    favoritesIcon.addEventListener('click', () => {
        favoritesOverlay.classList.remove('hidden');
        favoritesModal.classList.remove('hidden');
        renderFavorites();
    });

    // Fechar modal de favoritos
    closeFavoritesBtn.addEventListener('click', () => {
        favoritesOverlay.classList.add('hidden');
        favoritesModal.classList.add('hidden');
    });

    favoritesOverlay.addEventListener('click', () => {
        favoritesOverlay.classList.add('hidden');
        favoritesModal.classList.add('hidden');
    });

    // Adicionar produto aos favoritos
    document.querySelectorAll('.favorite-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const productName = e.target.parentElement.querySelector('h3').textContent;
            if (!favoriteProducts.includes(productName)) {
                favoriteProducts.push(productName);
                alert(`${productName} foi adicionado aos favoritos!`);
            } else {
                alert(`${productName} já está nos favoritos!`);
            }
        });
    });

    // Lista de favoritos
    function renderFavorites() {
        favoritesList.innerHTML = '';
        favoriteProducts.forEach(product => {
            const li = document.createElement('li');
            li.textContent = product;
            favoritesList.appendChild(li);

            // Remover dos favoritos
            const removeBtn = document.createElement('button');
            removeBtn.textContent = '-';
            removeBtn.classList.add('remove-btn');
            li.appendChild(removeBtn);

            removeBtn.addEventListener('click', () => {
                favoriteProducts = favoriteProducts.filter(fav => fav !== product);
                renderFavorites();
            });
        });
    }
});

