create database Celestia;
use Celestia;

create table cadastro (
	id_usuario int auto_increment primary key,
    nome varchar(225) not null,
    email varchar(225) not null unique,
    senha varchar(8) not null unique
);
select * from cadastro;
create table produtos (
	id_produto int auto_increment primary key,
    nome varchar(255) not null,
    descricao varchar(1000) not null,
    preco float
);
select * from produtos;

create table carrinho(
	precoTotal float,
    id_usuario int,
    id_produto int,
    id_carrinho int primary key auto_increment,
    foreign key (id_produto) references produtos(id_produto),
    foreign key (id_usuario) references cadastro(id_usuario)
);

INSERT INTO cadastro(nome, email, senha)
VALUES ("any", "anyrosasevero@gmail.com", "any123");
SELECT * FROM cadastro;

UPDATE cadastro SET email = "pietrafreitas@gmail.com", senha = "pietra123" WHERE id = 1;
SELECT * FROM cadastro WHERE id = 1;

DELETE FROM cadastro WHERE id = 1;
SELECT * FROM cadastro; 

INSERT INTO produtos(nome, descricao, preco)
VALUES ("LUA NOVA", "Lua se encontra entre a Terra e o Sol", 180.000);
SELECT * FROM produtos;

UPDATE produtos SET nome = "LUA DE SANGUE", descricao = "Eclipse lunar e Super Lua simultaneamente", preco = 1000.000 WHERE id = 1;
SELECT * FROM produtos WHERE id = 1;

DELETE FROM produtos WHERE id = 1;
SELECT * FROM produtos;
